{{-- kode layout untuk UI yang sudah template --}}
@extends('layouts.app')
{{-- kode untuk isi dari penambahan laporan buku --}}
@section('content')
{{-- membuat container dari isi --}}
    <div id="admin-content">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    {{-- Judul dari halaman --}}
                    <h2 class="admin-heading">Laporan Buku</h2>
                </div>
                <div class="offset-md-7 col-md-2">
                    {{-- Link ke list laporan yang sudah dibuat --}}
                    <a class="add-new" href="{{ route('book_issued') }}">List Laporan</a>
                </div>
            </div>
            <div class="row">
                {{-- form membuat laporan baru --}}
                <div class="offset-md-3 col-md-6">
                    <form class="yourform" action="{{ route('book_issue.create') }}" method="post"
                        autocomplete="off">
                        @csrf
                        {{-- isi form --}}
                        <div class="form-group">
                            {{-- bagian nama --}}
                            <label>Nama Anggota</label>
                            <select class="form-control" name="student_id" required>
                                {{-- pilihan untuk mencari anggota untuk input laporan --}}
                                <option value="">Pilih Anggota</option>
                                {{-- mencari anggota yang ada (sudah ada di database) --}}
                                @foreach ($students as $student)
                                {{-- menampilkan hasil ke dalam bentuk drop down list --}}
                                    <option value='{{ $student->id }}'>{{ $student->name }}</option>
                                @endforeach
                            </select>
                            {{-- memnunculkan pesan jika belum ada input data anggota --}}
                            @error('student_id')
                                <div class="alert alert-danger" role="alert">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            {{-- bagian buku --}}
                            <label>Nama Buku</label>
                            <select class="form-control" name="book_id" required>
                                {{-- pilihan untuk mencari buku untuk input laporan --}}
                                <option value="">Pilih Nama Buku</option>
                                {{-- mencari anggota yang ada (sudah ada di database) --}}
                                @foreach ($books as $book)
                                {{-- menampilkan hasil ke dalam bentuk drop down list --}}
                                    <option value='{{ $book->id }}'>{{ $book->name }}</option>
                                @endforeach
                            </select>
                            {{-- memnunculkan pesan jika belum ada input data buku --}}
                            @error('book_id')
                                <div class="alert alert-danger" role="alert">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        {{-- tombol untuk submit hasil input membuat laporan --}}
                        <input type="submit" name="Simpan" class="btn btn-danger" value="Simpan">
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
